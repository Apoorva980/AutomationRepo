package filehandling;

public class A {

	public B temp() {
		return new B();

	}

}
