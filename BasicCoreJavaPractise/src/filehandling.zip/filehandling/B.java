package filehandling;

public class B {

	public int sum(int a, int b) {
		return a + b;
	}

}
